import cv2
import math
import numpy as np

def read_image(filename): 
    return None
    
def resize_image(image,width,height):
    return None

def average_filter(image,kernel_size):
    return None

def gaussian_filter(image,kernel_size):
    return None

def median_filter(image,kernel_size):
    return None


def salt_and_pepper_noise(image):
    return None

def laplacian_filter(image):
    return None

def highboost_filter(image,a):
    return None
