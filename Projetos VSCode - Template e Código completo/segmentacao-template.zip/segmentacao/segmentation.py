import cv2
import numpy as np
from matplotlib import pyplot as plt


def read_image(filename):
    image = cv2.imread(filename)
    image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
    return image

def color_segmentation(image,lower_range,upper_range):
    None

def threshold(image, thresh):
    None

def otsu_threshold(image):
    None

def canny(image,lower_thresh_rate):
    None