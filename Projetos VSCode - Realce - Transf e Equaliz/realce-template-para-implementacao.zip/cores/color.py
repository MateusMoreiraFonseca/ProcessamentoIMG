import cv2
import numpy as np
import matplotlib.pyplot as plt

def read_image(filename):
    image = cv2.imread(filename)
    image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
    return image
    
def grayscale_image(image):
    return image

def negative_image(image):  
    return image

def log_transform(image):   
    return image

def gamma_correction(image,gamma): 
    return image

def gray_histogram(image):
    return       

def color_histogram(image):
    return

def show_histogram(image):
    return

def gray_contrast_stretch(image,max,min):
    return image

def color_contrast_stretch(image,max,min):
    return image

def contrast_stretch(image,max,min):
    return image

def gray_histogram_equalization(image):
    return image

def color_histogram_equalization(image):
    return image

def histogram_equalization(image):
    return image
